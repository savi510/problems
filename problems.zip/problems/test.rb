#sentence = "This is a test sentence"
#sentence.split("")
#puts sentence.split(" ")

def para(string)
string = ""
i = 0
if i < string.length
string[i] != string[(string.length - 1) - i] 
  puts i
end
end

para("whatup")